Create Static Mesh Assets From Dynamic Mesh Actor BP Constructor Scripts!

Required Plugin (Comes With UE5)

You will want to make sure you have the Geometry Script Plugin enabled for your project, before unzipping and loading this content!

♥

Rama
